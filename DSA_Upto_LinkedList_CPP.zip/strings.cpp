
#include <bits/stdc++.h>
using namespace std;

int main(){
    string s = "racecar";
    string t = s;
    reverse(t.begin(), t.end());
    if(s == t) cout << "Palindrome";
    else cout << "Not Palindrome";
    return 0;
}
